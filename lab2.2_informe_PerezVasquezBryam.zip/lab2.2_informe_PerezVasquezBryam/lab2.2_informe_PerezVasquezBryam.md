# LABORATORIO 2.2: GESTIÓN DE CONTENEDORES Y VOLÚMENES LOCALES

**Universidad Mayor, Real y Pontificia de San Francisco Xavier de Chuquisaca**  
**Facultad de Tecnología**  
**Carrera:** Ingeniería en Telecomunicaciones  
**Asignatura:** Trabajando en la Nube (COM610)  
**Docente:** Ing. Marcelo Quispe Ortega  
**Universitario:** Bryam Perez Vasquez  
**Paralelo:** 1  
**Semestre:** 2/2026  
**Fecha:** 14 de octubre de 2026  

---

## 1. Introducción

En el presente laboratorio se trabajó con Docker Engine para administrar contenedores, volúmenes y redes locales. Las prácticas permitieron comprobar la persistencia de información, el uso de bind mounts para desarrollo con Hot Reload, la comunicación entre contenedores mediante redes personalizadas, el balanceo de carga con Nginx y el despliegue de una arquitectura WordPress–MariaDB con persistencia independiente de base de datos y archivos.

## 2. Objetivos

- Aplicar volúmenes de Docker para conservar datos aunque un contenedor sea eliminado.
- Configurar Hot Reload con Node.js, Express y Nodemon.
- Crear redes Docker personalizadas y comprobar comunicación mediante nombres de contenedor.
- Implementar balanceo de carga con Nginx.
- Desplegar un Blog Institucional USFX con WordPress y MariaDB.
- Verificar la resiliencia de la arquitectura eliminando y reconstruyendo sus contenedores.

---

# 3. Desarrollo

## 3.1 Verificación inicial de Docker

Se verificó que Docker Engine se encuentre activo y posteriormente se ejecutó el contenedor de prueba `hello-world`.

![Servicio Docker activo](capturas/01_docker_servicio.png)

**Comentario:** El servicio Docker se encuentra en estado `active (running)`, confirmando que el daemon está listo para administrar imágenes y contenedores.

![Prueba hello-world](capturas/02_hello_world.png)

**Comentario:** `hello-world` fue descargado y ejecutado correctamente, verificando el funcionamiento del cliente Docker, el daemon y la conectividad con Docker Hub.

---

## 3.2 Ejercicio 3.1: Volúmenes para persistencia

### Creación del volumen

```bash
docker volume create datos-mysql
docker volume ls
```

![Creación de datos-mysql](capturas/03_volumen_datos_mysql.png)

**Comentario:** Se creó el volumen `datos-mysql`, administrado por Docker mediante el driver local.

### MariaDB utilizando el volumen

```bash
docker run -d -v datos-mysql:/var/lib/mysql --name mi-db \
  --env MARIADB_ROOT_PASSWORD=1234abcd mariadb
```

![MariaDB mi-db](capturas/04_mariadb_mi_db.png)

**Comentario:** El contenedor `mi-db` fue iniciado montando `datos-mysql` en `/var/lib/mysql`, ruta donde MariaDB almacena su información.

### Creación de base de datos y tabla

```sql
CREATE DATABASE test;
USE test;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(255) UNIQUE
);
```

![Base test y tabla usuarios](capturas/05_base_test_tabla_usuarios.png)

**Comentario:** Se verificó la existencia de la base `test` y de la tabla `usuarios`.

### Eliminación del contenedor y recreación

```bash
docker stop mi-db && docker rm mi-db

docker run -d -v datos-mysql:/var/lib/mysql --name nueva-db \
  --env MARIADB_ROOT_PASSWORD=1234abcd mariadb
```

![Recreación nueva-db](capturas/06_recreacion_nueva_db.png)

**Comentario:** El contenedor original fue eliminado y se creó `nueva-db` utilizando el mismo volumen.

![Persistencia de test y usuarios](capturas/07_persistencia_test_usuarios.png)

**Comentario:** La base `test` y la tabla `usuarios` continuaron disponibles, demostrando que el volumen es independiente del ciclo de vida del contenedor.

### Inspección del volumen

```bash
docker volume inspect datos-mysql
```

![Inspect datos-mysql](capturas/08_inspect_datos_mysql.png)

**Comentario:** Se identificó el punto de montaje del volumen en el sistema anfitrión.

### Navegación mediante Alpine

```bash
docker run -it --rm -v datos-mysql:/data alpine sh
ls -la /data
du -sh /data
```

![Contenido del volumen](capturas/09_alpine_contenido_volumen.png)

**Comentario:** El contenedor temporal Alpine permitió visualizar directamente los archivos persistidos por MariaDB.

---

## 3.3 Ejercicio 3.2: Persistencia y Hot Reload

### Preparación de Node.js

![Versiones Node y npm](capturas/10_node_npm.png)

**Comentario:** El servidor contaba con Node.js y npm para preparar el proyecto.

```bash
npm init
npm install express
npm install nodemon --save-dev
```

![Express y Nodemon](capturas/11_dependencias_express_nodemon.png)

**Comentario:** Se instalaron Express como framework web y Nodemon para detectar cambios en desarrollo.

### Aplicación Express

![index.js](capturas/12_index_js.png)

**Comentario:** `index.js` implementa un servidor Express que responde en la ruta `/` y escucha en el puerto 3000.

### Scripts de ejecución

![package.json](capturas/13_package_json_scripts.png)

**Comentario:** Se configuraron `npm start` y `npm run dev`; el segundo utiliza Nodemon.

### Dockerfile

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
CMD ["npm", "run", "dev"]
```

![Dockerfile Hot Reload](capturas/14_dockerfile_hot_reload.png)

**Comentario:** La imagen utiliza Node 20 Alpine y ejecuta la aplicación en modo desarrollo.

### Construcción de imagen

```bash
docker build -t mi-app-web:2.0 .
```

![Build mi-app-web](capturas/15_build_imagen.png)

**Comentario:** La imagen `mi-app-web:2.0` fue construida correctamente.

### Ejecución con bind mount

```bash
docker run -d -p 3000:3000 -v "$(pwd):/app" \
  --name mi-app-web-dev mi-app-web:2.0
```

![Contenedor Hot Reload](capturas/16_contenedor_hot_reload.png)

**Comentario:** El directorio local se vinculó a `/app`, permitiendo que los cambios hechos en el host sean visibles dentro del contenedor.

![Mensaje inicial](capturas/17_web_hello_world.png)

**Comentario:** La aplicación respondió inicialmente con `Hello World!`.

![Mensaje modificado](capturas/18_web_hot_reload.png)

**Comentario:** Después de modificar `index.js`, el navegador mostró el nuevo mensaje sin reconstruir ni reiniciar manualmente el contenedor.

![Logs Nodemon](capturas/19_logs_nodemon.png)

**Comentario:** Los logs confirman que Nodemon detectó el cambio y reinició automáticamente Node.js.

---

## 3.4 Ejercicio 3.3: Redes personalizadas

```bash
docker network create mi-red-app
docker network inspect mi-red-app
```

![Red mi-red-app](capturas/20_red_mi_red_app.png)

**Comentario:** `mi-red-app` utiliza el driver bridge y proporciona una subred propia para los contenedores.

```bash
docker run -d --network mi-red-app --name db-con-red \
  --env MARIADB_ROOT_PASSWORD=1234abcd mariadb

docker run --network mi-red-app --name app-con-red -it ubuntu:22.04 bash
```

Dentro de Ubuntu:

```bash
apt-get update && apt-get install -y iputils-ping
ping -c 3 db-con-red
```

![Ping entre contenedores](capturas/21_ping_db_con_red.png)

**Comentario:** La prueba tuvo 0 % de pérdida. Docker resolvió `db-con-red` mediante su DNS interno, permitiendo comunicación por nombre.

---

## 3.5 Ejercicio 3.4: Balanceo de carga con Nginx

### Directorios de los backends

![Directorios servidor1 y servidor2](capturas/22_directorios_balanceo.png)

**Comentario:** Se prepararon carpetas independientes para el contenido de ambos servidores.

![HTML servidor1](capturas/23_servidor1_html.png)

![HTML servidor2](capturas/24_servidor2_html.png)

**Comentario:** Cada backend devuelve un mensaje diferente para identificar qué servidor atendió la solicitud.

### Ejecución de los backends

```bash
docker run -d --network web-red --name servidor1 \
  -v $(pwd)/servidor1:/usr/share/nginx/html nginx

docker run -d --network web-red --name servidor2 \
  -v $(pwd)/servidor2:/usr/share/nginx/html nginx
```

![Servidores Nginx](capturas/25_servidores_nginx.png)

**Comentario:** `servidor1` y `servidor2` quedaron activos dentro de la misma red.

### Configuración del balanceador

![nginx.conf](capturas/26_nginx_conf.png)

**Comentario:** El bloque `upstream balanceador` agrupa ambos backends y `proxy_pass` dirige las solicitudes hacia ellos.

```bash
docker run -d --network web-red -p 8080:80 --name balanceador \
  -v $(pwd)/nginx.conf:/etc/nginx/nginx.conf nginx
```

![Balanceador activo](capturas/27_balanceador_docker_ps.png)

**Comentario:** El tercer Nginx publica el puerto 8080 del host hacia el puerto 80 del contenedor.

![Respuesta Servidor 1](capturas/28_balanceo_servidor1.png)

![Respuesta Servidor 2](capturas/29_balanceo_servidor2.png)

![Prueba con curl](capturas/30_balanceo_curl.png)

**Comentario:** Las respuestas alternadas demuestran la distribución de solicitudes entre los dos backends mediante el balanceo round-robin por defecto de Nginx.

---

# 4. Práctica individual: Blog Institucional USFX

## 4.1 Infraestructura de red y almacenamiento

```bash
docker network create red-nube-usfx
docker volume create vol-db-datos
docker volume create vol-wp-contenido
```

![Red y volúmenes](capturas/31_red_volumenes_blog.png)

**Comentario:** Se creó una red aislada y dos volúmenes: uno para MariaDB y otro para `wp-content`.

## 4.2 Variables de entorno

Se creó `blog.env` con las variables requeridas y se protegió con permisos 600.

![blog.env protegido](capturas/32_blog_env_seguro.png)

**Comentario:** Las variables fueron centralizadas en un archivo y las contraseñas no fueron expuestas en la evidencia.

## 4.3 Nodo de datos MariaDB

```bash
docker run -d \
  --name db-usfx \
  --network red-nube-usfx \
  --env-file blog.env \
  -v vol-db-datos:/var/lib/mysql \
  mariadb \
  --character-set-server=utf8mb4 \
  --collation-server=utf8mb4_unicode_ci
```

![MariaDB db-usfx](capturas/33_mariadb_db_usfx.png)

**Comentario:** Los logs muestran `ready for connections`, confirmando que MariaDB quedó operativo en el puerto 3306.

## 4.4 Configuración de PHP

Contenido de `uploads.ini`:

```ini
upload_max_filesize = 64M
post_max_size = 64M
memory_limit = 128M
```

![uploads.ini](capturas/34_uploads_ini.png)

## 4.5 Nodo WordPress

```bash
docker run -d \
  --name wordpress-usfx \
  --network red-nube-usfx \
  --env-file blog.env \
  -v vol-wp-contenido:/var/www/html/wp-content \
  -v $(pwd)/uploads.ini:/usr/local/etc/php/conf.d/uploads.ini \
  -p 8081:80 \
  wordpress
```

![Despliegue WordPress](capturas/35_wordpress_despliegue.png)

**Comentario:** WordPress quedó conectado a la misma red que MariaDB, persistiendo `wp-content` y publicándose en el puerto 8081.

![Verificación PHP](capturas/36_php_limites.png)

**Comentario:** PHP confirmó límites de 64 MB para subida y envío de archivos, y 128 MB de memoria.

![Escritorio WordPress](capturas/37_wordpress_escritorio.png)

**Comentario:** El panel administrativo fue accesible desde el navegador del equipo anfitrión.

## 4.6 Preparación de la prueba de persistencia

![Tema antes de destruir contenedores](capturas/38_tema_antes.png)

**Comentario:** Se activó el tema Twenty Seventeen como evidencia previa.

![Imagen antes de destruir contenedores](capturas/39_imagen_antes.png)

**Comentario:** Se cargó una imagen en la biblioteca multimedia, almacenada físicamente dentro de `wp-content/uploads`.

## 4.7 Eliminación de contenedores

```bash
docker rm -f wordpress-usfx db-usfx
docker ps
```

![Eliminación de contenedores](capturas/40_eliminacion_contenedores.png)

**Comentario:** WordPress y MariaDB fueron eliminados completamente antes de comprobar la persistencia.

## 4.8 Auditoría de volúmenes

```bash
docker volume inspect vol-db-datos
docker volume inspect vol-wp-contenido
docker volume ls
```

![Volúmenes persistentes](capturas/41_volumenes_persisten.png)

**Comentario:** Los dos volúmenes continuaron existiendo aun después de eliminar los contenedores.

![Contenido de los volúmenes](capturas/42_contenido_volumenes.png)

**Comentario:** Con Alpine se verificó directamente que `vol-wp-contenido` conservaba `themes` y `uploads`, y que el volumen de MariaDB mantenía sus archivos de datos.

## 4.9 Reconstrucción de la infraestructura

![Reconstrucción MariaDB](capturas/43_reconstruccion_db.png)

**Comentario:** `db-usfx` fue recreado apuntando al mismo `vol-db-datos` y volvió a quedar listo para conexiones.

![Reconstrucción WordPress](capturas/44_reconstruccion_wordpress.png)

**Comentario:** WordPress fue recreado reutilizando `vol-wp-contenido` y el mismo archivo de variables de entorno.

## 4.10 Verificación final

![Tema después de reconstruir](capturas/45_tema_despues.png)

**Comentario:** Twenty Seventeen continuó activo después de eliminar y reconstruir los contenedores.

![Imagen después de reconstruir](capturas/46_imagen_despues.png)

**Comentario:** La imagen continuó presente en la biblioteca multimedia. Esto confirma la persistencia efectiva de `wp-content`.

---

# 5. Resultados

- Los datos de MariaDB persistieron aunque el contenedor original fue eliminado.
- El bind mount permitió realizar cambios en el código y verlos reflejados mediante Hot Reload.
- Las redes personalizadas permitieron comunicación por nombre entre contenedores.
- Nginx distribuyó tráfico entre dos servidores backend.
- WordPress y MariaDB trabajaron como servicios separados dentro de una misma red.
- Los datos SQL y los archivos de `wp-content` permanecieron después de eliminar y reconstruir los contenedores.

# 6. Conclusiones

El laboratorio permitió comprobar que un contenedor debe considerarse un componente reemplazable, mientras que la información que requiere permanencia debe almacenarse fuera de su sistema de archivos efímero. Los volúmenes de Docker proporcionaron esta persistencia tanto para MariaDB como para el contenido de WordPress.

También se comprobó que Docker permite crear redes privadas en las que los servicios se comunican mediante nombres, reduciendo la dependencia de direcciones IP fijas. El ejercicio con Nginx permitió observar cómo un proxy inverso puede distribuir solicitudes entre múltiples servidores.

Finalmente, la prueba de resiliencia del Blog Institucional USFX confirmó el correcto diseño de persistencia: después de eliminar por completo WordPress y MariaDB, los contenedores fueron reconstruidos utilizando los mismos volúmenes y se recuperaron tanto la configuración del sitio como el tema y el archivo multimedia cargado previamente.
