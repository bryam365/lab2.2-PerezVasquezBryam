# Laboratorio 2.2 - Gestión de Contenedores y Volúmenes Locales

**Universitario:** Bryam Perez Vasquez  
**Asignatura:** Trabajando en la Nube (COM610)  
**Docente:** Ing. Marcelo Quispe Ortega  
**Semestre:** 2/2026

## Estructura

- `hot-reload-app/`: aplicación Node.js + Express + Nodemon.
- `balanceo-nginx/`: dos backends Nginx y configuración del balanceador.
- `blog-usfx/`: configuración del despliegue WordPress + MariaDB.

## Comandos principales

### Hot Reload

```bash
cd hot-reload-app
npm install
docker build -t mi-app-web:2.0 .
docker run -d -p 3000:3000 -v "$(pwd):/app" --name mi-app-web-dev mi-app-web:2.0
```

### Red y balanceo Nginx

```bash
docker network create web-red

docker run -d --network web-red --name servidor1   -v $(pwd)/balanceo-nginx/servidor1:/usr/share/nginx/html nginx

docker run -d --network web-red --name servidor2   -v $(pwd)/balanceo-nginx/servidor2:/usr/share/nginx/html nginx

docker run -d --network web-red -p 8080:80 --name balanceador   -v $(pwd)/balanceo-nginx/nginx.conf:/etc/nginx/nginx.conf nginx
```

### Blog Institucional USFX

```bash
docker network create red-nube-usfx
docker volume create vol-db-datos
docker volume create vol-wp-contenido

cd blog-usfx
chmod 600 blog.env

docker run -d   --name db-usfx   --network red-nube-usfx   --env-file blog.env   -v vol-db-datos:/var/lib/mysql   mariadb   --character-set-server=utf8mb4   --collation-server=utf8mb4_unicode_ci

docker run -d   --name wordpress-usfx   --network red-nube-usfx   --env-file blog.env   -v vol-wp-contenido:/var/www/html/wp-content   -v "$(pwd)/uploads.ini:/usr/local/etc/php/conf.d/uploads.ini"   -p 8081:80   wordpress
```

## Prueba de resiliencia

```bash
docker rm -f wordpress-usfx db-usfx
docker volume inspect vol-db-datos
docker volume inspect vol-wp-contenido
```

Después se vuelven a ejecutar los dos comandos de despliegue anteriores apuntando a los mismos volúmenes.

> Nota: `blog.env` contiene credenciales creadas exclusivamente para este laboratorio local. Deben cambiarse si el proyecto se reutiliza fuera del entorno académico.
